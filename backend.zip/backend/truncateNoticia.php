<?php

include "./classes/Noticia.php";
include "./classes/DAO.php";

$n = new Noticia();
$n->clear();

?>